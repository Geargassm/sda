package cedrou.factorio.enemies.client.model;

import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

// Made with Blockbench 4.12.4
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports
public class Modelsmallspitters<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("factorio_enemies", "modelsmallspitters"), "main");
	public final ModelPart biter;
	public final ModelPart carapace;
	public final ModelPart tete;
	public final ModelPart bone;
	public final ModelPart bone2;
	public final ModelPart p1;
	public final ModelPart p2;
	public final ModelPart p3;
	public final ModelPart p4;
	public final ModelPart p5;
	public final ModelPart p6;
	public final ModelPart pates_avant_gauche;
	public final ModelPart pates_avant_doite;
	public final ModelPart pates_milieu_droit;
	public final ModelPart pates_millieu_gauche;
	public final ModelPart pates_arriere_gauche;
	public final ModelPart pates_arriere_doite;

	public Modelsmallspitters(ModelPart root) {
		this.biter = root.getChild("biter");
		this.carapace = this.biter.getChild("carapace");
		this.tete = this.carapace.getChild("tete");
		this.bone = this.tete.getChild("bone");
		this.bone2 = this.tete.getChild("bone2");
		this.p1 = this.carapace.getChild("p1");
		this.p2 = this.carapace.getChild("p2");
		this.p3 = this.carapace.getChild("p3");
		this.p4 = this.carapace.getChild("p4");
		this.p5 = this.carapace.getChild("p5");
		this.p6 = this.carapace.getChild("p6");
		this.pates_avant_gauche = this.biter.getChild("pates_avant_gauche");
		this.pates_avant_doite = this.biter.getChild("pates_avant_doite");
		this.pates_milieu_droit = this.biter.getChild("pates_milieu_droit");
		this.pates_millieu_gauche = this.biter.getChild("pates_millieu_gauche");
		this.pates_arriere_gauche = this.biter.getChild("pates_arriere_gauche");
		this.pates_arriere_doite = this.biter.getChild("pates_arriere_doite");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition biter = partdefinition.addOrReplaceChild("biter", CubeListBuilder.create(), PartPose.offset(0.0F, 27.0F, 0.0F));
		PartDefinition carapace = biter.addOrReplaceChild("carapace", CubeListBuilder.create(), PartPose.offset(-1.0F, -4.8F, -3.4F));
		PartDefinition tete = carapace.addOrReplaceChild("tete", CubeListBuilder.create(), PartPose.offset(2.0F, 0.5F, -1.0F));
		PartDefinition bone = tete.addOrReplaceChild("bone", CubeListBuilder.create(), PartPose.offset(-1.7651F, -0.1645F, -0.4096F));
		PartDefinition carapace_r1 = bone.addOrReplaceChild("carapace_r1", CubeListBuilder.create().texOffs(0, 0).addBox(-1.0F, -1.0F, -1.0F, 3.0F, 2.0F, 2.0F, new CubeDeformation(0.3F)),
				PartPose.offsetAndRotation(-0.2349F, 0.1645F, 0.4096F, 0.0F, 0.9599F, -0.6109F));
		PartDefinition bone2 = tete.addOrReplaceChild("bone2", CubeListBuilder.create(), PartPose.offset(-0.2349F, -0.1645F, -0.4096F));
		PartDefinition carapace_r2 = bone2.addOrReplaceChild("carapace_r2", CubeListBuilder.create().texOffs(0, 0).mirror().addBox(-2.0F, -1.0F, -1.0F, 3.0F, 2.0F, 2.0F, new CubeDeformation(0.3F)).mirror(false),
				PartPose.offsetAndRotation(0.2349F, 0.1645F, 0.4096F, 0.0F, -0.9599F, 0.6109F));
		PartDefinition p1 = carapace.addOrReplaceChild("p1", CubeListBuilder.create(), PartPose.offset(0.0F, 0.0F, 0.0F));
		PartDefinition carapace_r3 = p1.addOrReplaceChild("carapace_r3", CubeListBuilder.create().texOffs(12, 0).addBox(-1.0F, -1.0F, -1.0F, 3.0F, 2.0F, 2.0F, new CubeDeformation(0.3F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.6109F));
		PartDefinition carapace_r4 = p1.addOrReplaceChild("carapace_r4", CubeListBuilder.create().texOffs(12, 0).mirror().addBox(-2.0F, -1.0F, -1.0F, 3.0F, 2.0F, 2.0F, new CubeDeformation(0.3F)).mirror(false),
				PartPose.offsetAndRotation(2.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.6109F));
		PartDefinition p2 = carapace.addOrReplaceChild("p2", CubeListBuilder.create(), PartPose.offset(2.0F, -0.5F, 2.6F));
		PartDefinition carapace_r5 = p2.addOrReplaceChild("carapace_r5", CubeListBuilder.create().texOffs(0, 0).mirror().addBox(-2.0F, -1.0F, -2.0F, 3.0F, 2.0F, 3.0F, new CubeDeformation(0.3F)).mirror(false),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.6109F));
		PartDefinition carapace_r6 = p2.addOrReplaceChild("carapace_r6", CubeListBuilder.create().texOffs(0, 0).addBox(-1.0F, -1.0F, -2.0F, 3.0F, 2.0F, 3.0F, new CubeDeformation(0.3F)),
				PartPose.offsetAndRotation(-2.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.6109F));
		PartDefinition p3 = carapace.addOrReplaceChild("p3", CubeListBuilder.create(), PartPose.offset(0.0F, -0.2F, 4.2F));
		PartDefinition carapace_r7 = p3.addOrReplaceChild("carapace_r7", CubeListBuilder.create().texOffs(10, 9).addBox(-1.0F, -1.0F, -1.0F, 3.0F, 2.0F, 2.0F, new CubeDeformation(0.3F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.6109F));
		PartDefinition carapace_r8 = p3.addOrReplaceChild("carapace_r8", CubeListBuilder.create().texOffs(10, 9).mirror().addBox(-2.0F, -1.0F, -1.0F, 3.0F, 2.0F, 2.0F, new CubeDeformation(0.3F)).mirror(false),
				PartPose.offsetAndRotation(2.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.6109F));
		PartDefinition p4 = carapace.addOrReplaceChild("p4", CubeListBuilder.create(), PartPose.offset(2.0F, 0.0F, 5.9F));
		PartDefinition carapace_r9 = p4.addOrReplaceChild("carapace_r9", CubeListBuilder.create().texOffs(10, 5).mirror().addBox(-2.0F, -1.0F, -1.0F, 3.0F, 2.0F, 2.0F, new CubeDeformation(0.3F)).mirror(false),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.6109F));
		PartDefinition carapace_r10 = p4.addOrReplaceChild("carapace_r10", CubeListBuilder.create().texOffs(10, 5).addBox(-1.0F, -1.0F, -1.0F, 3.0F, 2.0F, 2.0F, new CubeDeformation(0.3F)),
				PartPose.offsetAndRotation(-2.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.6109F));
		PartDefinition p5 = carapace.addOrReplaceChild("p5", CubeListBuilder.create(), PartPose.offset(2.0F, 0.3F, 7.4F));
		PartDefinition carapace_r11 = p5.addOrReplaceChild("carapace_r11", CubeListBuilder.create().texOffs(0, 5).mirror().addBox(-2.0F, -1.0F, -1.0F, 3.0F, 2.0F, 2.0F, new CubeDeformation(0.3F)).mirror(false),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.6109F));
		PartDefinition carapace_r12 = p5.addOrReplaceChild("carapace_r12", CubeListBuilder.create().texOffs(0, 5).addBox(-1.0F, -1.0F, -1.0F, 3.0F, 2.0F, 2.0F, new CubeDeformation(0.3F)),
				PartPose.offsetAndRotation(-2.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.6109F));
		PartDefinition p6 = carapace.addOrReplaceChild("p6", CubeListBuilder.create(), PartPose.offset(2.0F, 0.6F, 8.5F));
		PartDefinition carapace_r13 = p6.addOrReplaceChild("carapace_r13", CubeListBuilder.create().texOffs(0, 0).mirror().addBox(-2.0F, -1.0F, -1.0F, 3.0F, 2.0F, 2.0F, new CubeDeformation(0.3F)).mirror(false),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.6109F));
		PartDefinition carapace_r14 = p6.addOrReplaceChild("carapace_r14", CubeListBuilder.create().texOffs(0, 0).addBox(-1.0F, -1.0F, -1.0F, 3.0F, 2.0F, 2.0F, new CubeDeformation(0.3F)),
				PartPose.offsetAndRotation(-2.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.6109F));
		PartDefinition pates_avant_gauche = biter.addOrReplaceChild("pates_avant_gauche", CubeListBuilder.create(), PartPose.offsetAndRotation(2.1836F, -2.7136F, -3.0585F, -0.2618F, 0.0F, 0.0F));
		PartDefinition cube_r1 = pates_avant_gauche.addOrReplaceChild("cube_r1", CubeListBuilder.create().texOffs(2, 1).addBox(0.0F, -3.0F, -1.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.3F)),
				PartPose.offsetAndRotation(-0.9336F, 1.6401F, 0.5F, 0.0F, 0.0F, -0.1745F));
		PartDefinition pates_avant_doite = biter.addOrReplaceChild("pates_avant_doite", CubeListBuilder.create(), PartPose.offsetAndRotation(-2.1836F, -2.7136F, -3.0585F, -0.2618F, 0.0F, 0.0F));
		PartDefinition cube_r2 = pates_avant_doite.addOrReplaceChild("cube_r2", CubeListBuilder.create().texOffs(2, 1).mirror().addBox(-1.0F, -3.0F, -1.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.3F)).mirror(false),
				PartPose.offsetAndRotation(0.9336F, 1.6401F, 0.5F, 0.0F, 0.0F, 0.1745F));
		PartDefinition pates_milieu_droit = biter.addOrReplaceChild("pates_milieu_droit", CubeListBuilder.create(), PartPose.offset(-1.8348F, -2.0724F, -0.9654F));
		PartDefinition cube_r3 = pates_milieu_droit.addOrReplaceChild("cube_r3", CubeListBuilder.create().texOffs(4, 17).addBox(-1.0F, -3.0F, -1.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.3F)),
				PartPose.offsetAndRotation(1.0119F, 1.0724F, 0.5F, 0.0F, 0.0F, 0.1745F));
		PartDefinition pates_millieu_gauche = biter.addOrReplaceChild("pates_millieu_gauche", CubeListBuilder.create(), PartPose.offset(2.2619F, -2.0724F, -0.5F));
		PartDefinition cube_r4 = pates_millieu_gauche.addOrReplaceChild("cube_r4", CubeListBuilder.create().texOffs(4, 17).mirror().addBox(0.0F, -3.0F, -1.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.3F)).mirror(false),
				PartPose.offsetAndRotation(-1.0119F, 1.0724F, 0.5F, 0.0F, 0.0F, -0.1745F));
		PartDefinition pates_arriere_gauche = biter.addOrReplaceChild("pates_arriere_gauche", CubeListBuilder.create(), PartPose.offsetAndRotation(2.5076F, -2.9541F, 2.9857F, 0.1745F, -0.2618F, 0.0F));
		PartDefinition cube_r5 = pates_arriere_gauche.addOrReplaceChild("cube_r5", CubeListBuilder.create().texOffs(10, 13).mirror().addBox(0.0F, -3.0F, -1.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.3F)).mirror(false),
				PartPose.offsetAndRotation(-1.0119F, 1.0724F, 0.5F, 0.0F, 0.0F, -0.1745F));
		PartDefinition pates_arriere_doite = biter.addOrReplaceChild("pates_arriere_doite", CubeListBuilder.create(), PartPose.offsetAndRotation(-2.4627F, -3.0209F, 3.1534F, 0.1745F, 0.2618F, 0.0F));
		PartDefinition cube_r6 = pates_arriere_doite.addOrReplaceChild("cube_r6", CubeListBuilder.create().texOffs(10, 13).addBox(-1.0F, -3.0F, -1.0F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.3F)),
				PartPose.offsetAndRotation(1.0119F, 1.0724F, 0.5F, 0.0F, 0.0F, 0.1745F));
		return LayerDefinition.create(meshdefinition, 32, 32);
	}

	@Override
	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
		biter.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}
}
